<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: install
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /soap/language/pt_br/language.php

define('SOAP_NO_USER_PW','O nome de usu');
define('SOAP_USER_NOT_FOUND','O nome de usu');
define('SOAP_PASSWORD_NOT_FOUND','A senha submetida n');
define('SOAP_UNEXPECTED_ERROR','Um c');
define('SOAP_XML_SUBMITTED_SO','XML submeteu Ordem de Venda');
define('SOAP_ACCOUNT_PROBLEM','N');
define('SOAP_MISSING_FIELDS','Ordem # %s n');
define('AUDIT_LOG_SOAP_10_ADDED','SOAP Ordens Venda - Inserir');
define('AUDIT_LOG_SOAP_12_ADDED','SOAP Vendas/Fatura - Inserir');
define('SOAP_10_SUCCESS','Ordem Venda %s foi baixada com sucesso.');
define('SOAP_12_SUCCESS','Fatura Venda %s foi baixada com sucesso.');

?>
