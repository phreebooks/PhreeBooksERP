<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: rma
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/pt_br/language.php

define('RMA_ACTION_99','Outros (Especificar nas Notas)');
define('RMA_ACTION_6','Teste & Creditar');
define('RMA_ACTION_5','Scrap');
define('RMA_ACTION_4','Substituição por Garantia');
define('RMA_ACTION_3','Testar & Substituir');
define('RMA_ACTION_2','Devolver ao Cliente');
define('RMA_ACTION_1','Devolver ao Estoque');
define('RMA_ACTION_0','Selecionar Ação ...');
define('RMA_REASON_99','Outros (Especificar nas Notas)');
define('RMA_REASON_80','Conector Errado');
define('RMA_REASON_7','Envio Duplicado');
define('RMA_REASON_6','Recusado pelo Cliente');
define('RMA_REASON_5','Avariado no Transporte');
define('RMA_REASON_4','Defeituoso/Trocar');
define('RMA_REASON_3','Não serviu');
define('RMA_REASON_2','Encomenda Produto Errado');
define('RMA_REASON_1','Não Precisa');
define('RMA_REASON_0','Selecione o motivo para ARM ...');
define('RMA_STATUS_99','Fechado');
define('RMA_STATUS_90','Fechado - Não recebido');
define('RMA_STATUS_9','Reclamação Avaria');
define('RMA_STATUS_8','Fechado - Sem Garantia');
define('RMA_STATUS_7','Fechado - Substotuído');
define('RMA_STATUS_6','Aguardando Crédito');
define('RMA_STATUS_5','Em Teste/Avaliação');
define('RMA_STATUS_4','A Disposição');
define('RMA_STATUS_3','Recebendo Verificação');
define('RMA_STATUS_2','Partes Recebidas');
define('RMA_STATUS_1','ARM Criada/Aguardando Peças');
define('RMA_STATUS_0','Selecione Situação ...');
define('RMA_LOG_USER_UPDATE','ARM Alterada - ARM# ');
define('RMA_LOG_USER_ADD','ARM Criada - ARM# ');
define('RMA_ROW_DELETE_ALERT','Tem certeza de que quer remover esta linha?');
define('RMA_MSG_DELETE_RMA','Are you sure you want to \',\'Tem certeza de que quer remover ');
define('RMA_ERROR_CANNOT_DELETE','Houve um erro ao remover a ARM.');
define('RMA_MESSAGE_DELETE','A ARM foi removida com sucesso.');
define('RMA_MESSAGE_SUCCESS_UPDATE','ARM  # alterada com sucesso');
define('RMA_MESSAGE_SUCCESS_ADD','ARM  # criada com sucesso');
define('RMA_MESSAGE_ERROR','Houve um erro ao criar/alterar a ARM.');
define('RMA_DISPOSITION_DESC','<b>Mude a situação para Fechado e feche quando completado!</b>');
define('TEXT_RECEIVING','Recebendo');
define('TEXT_RECEIVE_TRACKING_NUM','Conhecimento Transportadora #');
define('TEXT_RECEIVE_CARRIER','Transportadora');
define('TEXT_RECEIVED_BY','Recebido por');
define('TEXT_RECEIVE_DATE','Data Recebimento');
define('TEXT_ENTERED_BY','Registrado Por');
define('TEXT_REASON_FOR_RETURN','Motivo Retorno');
define('TEXT_DISPOSITION','Disposição');
define('TEXT_DETAILS','Detalhes');
define('TEXT_DATE_WARRANTY','Data Expiração Garantia');
define('TEXT_DATE_MANUFACTURE','Fabricante DLC');
define('TEXT_TELEPHONE','Telefone');
define('TEXT_CUSTOMER_ID','ID Cliente');
define('TEXT_CALLER_NAME','Nome Contato');
define('TEXT_ORIG_PO_SO','Original OV/OC #');
define('TEXT_INVOICE_DATE','Data Fatura');
define('TEXT_PURCHASE_INVOICE_ID','Venda/Fatura #');
define('TEXT_CREATION_DATE','Criado');
define('TEXT_ASSIGNED_BY_SYSTEM','(Definido pelo Sistema)');
define('TEXT_RMA_ID','Número ARM');
define('TEXT_RMAS','ARMs');
define('MENU_HEADING_NEW_RMA','Criar Nova ARM');
define('BOX_RMA_MAINTAIN','Autorizações Retorno Material');

?>
