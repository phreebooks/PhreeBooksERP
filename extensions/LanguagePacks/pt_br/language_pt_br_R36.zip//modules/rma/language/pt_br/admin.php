<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: rma
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/pt_br/admin.php

define('NEXT_RMA_NUM_DESC','Próximo Número ARM');
define('MODULE_RMA_DESCRIPTION','O módulo de Autorização Retorno Material (ARM) gerencia as devoluções de produtos de clientes.');
define('MODULE_RMA_TITLE','Módulo ARM');

?>
