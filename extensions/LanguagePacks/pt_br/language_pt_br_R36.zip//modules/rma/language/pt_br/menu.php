<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: rma
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/rma/language/pt_br/menu.php

define('BOX_RMA_MODULE','ARM');
define('MENU_HEADING_RMA','Retorna');

?>
