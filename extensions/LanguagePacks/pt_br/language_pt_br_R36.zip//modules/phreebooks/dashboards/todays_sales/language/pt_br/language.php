<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-todays_sales
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_sales/language/pt_br/language.php

define('CP_TODAYS_SALES_TITLE','Today\\\'s Sales');
define('CP_TODAYS_SALES_DESCRIPTION','Lists today\\\'s sales/invoices. Links to reveiw the invoice are also provided.');

?>
