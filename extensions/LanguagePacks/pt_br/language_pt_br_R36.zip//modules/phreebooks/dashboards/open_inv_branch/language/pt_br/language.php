<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-open_inv_branch
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv_branch/language/pt_br/language.php

define('CP_OPEN_INV_BRANCH_TITLE','Faturas em Aberto por Filial');
define('CP_OPEN_INV_BRANCH_DESCRIPTION','Links to reveiw the invoice are also provided. Lista as vendas/faturas em aberto pela filial padrão do usuário.');

?>
