<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-open_inv
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/open_inv/language/pt_br/language.php

define('CP_OPEN_INV_TITLE','Faturas em Aberto');
define('CP_OPEN_INV_DESCRIPTION','Lista as vendas e faturas em aberto. Link para as faturas em detalhe.');

?>
