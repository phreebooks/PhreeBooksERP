<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-so_status
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/so_status/language/pt_br/language.php

define('CP_SO_STATUS_TITLE','Ordens de Venda em Aberto');
define('CP_SO_STATUS_DESCRIPTION','Lista ordens de venda com status em aberto. Mostra ordem de venda em detalhe.');
define('CP_SO_STATUS_SORT_ORDER','Ordenar por Data Lançamento');
define('CP_SO_STATUS_HIDE_FUTURE','Restringir a Hoje e Anteriores');

?>
