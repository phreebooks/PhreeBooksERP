<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-todays_s_quotes
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/todays_s_quotes/language/pt_br/language.php

define('CP_TODAYS_S_QUOTES_TITLE','Today\\\'s Sales Quotes');
define('CP_TODAYS_S_QUOTES_DESCRIPTION','Lists today\\\'s sales quotes. Links to review the quotes are also provided.');

?>
