<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-mini_financial
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/mini_financial/language/pt_br/language.php

define('CP_MINI_FINANCIAL_TITLE','Meu Histórico Financeiro');
define('CP_MINI_FINANCIAL_DESCRIPTION','Lista uma versão resumida de seu histórico financeiro.');
define('CP_MINI_FINANCIAL_NO_OPTIONS','Não há opções de seleçaõ para este item!');
define('RW_FIN_CURRENT_ASSETS','Ativos Correntes');
define('RW_FIN_PROP_EQUIP','Imóveis & Equipamentos');
define('RW_FIN_HEAD_0','Caixa');
define('RW_FIN_HEAD_2','Recebíveis');
define('RW_FIN_HEAD_4','Inventário');
define('RW_FIN_HEAD_6','Outros Ativos');
define('RW_FIN_HEAD_8','Não Utilizado');
define('RW_FIN_HEAD_10','Não Utilizado');
define('RW_FIN_HEAD_12','Não Utilizado');
define('RW_FIN_HEAD_20','Não Utilizado');
define('RW_FIN_HEAD_22','Não Utilizado');
define('RW_FIN_HEAD_24','Não Utilizado');
define('RW_FIN_HEAD_40','Não Utilizado');
define('RW_FIN_HEAD_42','Não Utilizado');
define('RW_FIN_HEAD_44','Não Utilizado');
define('RW_FIN_ASSETS','Total Ativos');
define('RW_FIN_INCOME','Total Receitas');
define('RW_FIN_CUR_LIABILITIES','Passivo Corrente');
define('RW_FIN_LT_LIABILITIES','Passivo de Longo Prazo');
define('RW_FIN_TOTAL_LIABILITIES','Total Passivos');
define('RW_FIN_TOTAL_INCOME','Total Receitas');
define('RW_FIN_COST_OF_SALES','Custo de Vendas');
define('RW_FIN_GROSS_PROFIT','Lucro Bruto');
define('RW_FIN_EXPENSES','Despesas');
define('RW_FIN_NET_INCOME','Receita Líquida');
define('RW_FIN_CAPITAL','Capital');
define('RW_FIN_TOTAL_LIABILITIES_CAPITAL','Total Passivos & Capital');

?>
