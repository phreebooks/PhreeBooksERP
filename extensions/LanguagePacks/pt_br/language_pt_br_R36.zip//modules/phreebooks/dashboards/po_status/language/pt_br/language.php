<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks-po_status
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/dashboards/po_status/language/pt_br/language.php

define('CP_PO_STATUS_TITLE','Ordens de Compra em Aberto');
define('CP_PO_STATUS_DESCRIPTION','Lista ordens de compra com status em aberto. Mostra a ordem de compra em detalhe.');
define('CP_PO_STATUS_SORT_ORDER','Ordenar por Data de Lançamento');
define('CP_PO_STATUS_HIDE_FUTURE','Restringir a Hoje e Anteriores');

?>
