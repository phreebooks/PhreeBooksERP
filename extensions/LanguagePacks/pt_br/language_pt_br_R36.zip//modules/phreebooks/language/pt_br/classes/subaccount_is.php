<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/subaccount_is.php

define('RW_SUB_ACT_BAL_SHT_IS_ACCT','0');
define('RW_FIN_NET_INCOME','Receita Líquida');
define('RW_RECORD_ID','Coluna Espaço Reservado');

?>
