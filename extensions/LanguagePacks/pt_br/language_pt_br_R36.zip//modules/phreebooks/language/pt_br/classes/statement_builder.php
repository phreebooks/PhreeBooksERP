<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/statement_builder.php

define('TEXT_AGE','Idade');
define('RW_SB_POST_DATE','Data Envio');
define('RW_SB_RECORD_ID','ID Registro');
define('RW_SB_JOURNAL_ID','ID Diário');
define('RW_SB_CUSTOMER_ID','ID Cliente');
define('RW_SB_ACCOUNT_NUMBER','Número Conta');
define('RW_SB_SALES_REP','Rep Vendas');
define('RW_SB_TERMS','Condições');
define('RW_SB_CUSTOMER_RECORD','ID Registro Cobrança');
define('RW_SB_BILL_PRIMARY_NAME','Cobrança Nome');
define('RW_SB_BILL_CONTACT','Cobrança Contato');
define('RW_SB_BILL_ADDRESS2','Cobrança Endereço 2');
define('RW_SB_BILL_ADDRESS1','Cobrança Endereço 1');
define('RW_SB_BILL_CITY','Cobrança Município');
define('RW_SB_BILL_STATE','Cobrança Unidade Federal');
define('RW_SB_BILL_ZIP','Cobrança CEP');
define('RW_SB_BILL_COUNTRY','Cobrança País');
define('RW_SB_BILL_TELE1','Cobrança Telefone 1');
define('RW_SB_BILL_FAX','Cobrança Fax');
define('RW_SB_BILL_TELE2','Cobrança Telefone 2');
define('RW_SB_BILL_WEBSITE','Cobrança Website');
define('RW_SB_BILL_EMAIL','Cobrança E-mail');
define('RW_SB_BALANCE_DUE','Saldo Aberto');
define('RW_SB_PRIOR_BALANCE','Saldo Anterior');
define('RW_SB_JOURNAL_DESC','Descrição Diário');
define('RW_SB_PO_NUM','Número OC');
define('RW_SB_INV_NUM','Número Fatura');
define('RW_SB_PMT_RCVD','Pmt Recebido');
define('RW_SB_INV_TOTAL','Valor Fatura');
define('RW_SB_DUE_DATE','Vencimento');

?>
