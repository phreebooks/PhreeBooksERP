<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreebooks
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreebooks/language/pt_br/classes/income_statement.php

define('RW_FIN_REVENUES','Receitas');
define('RW_FIN_GROSS_PROFIT','Lucro Bruto');
define('RW_FIN_COST_OF_SALES','Custo Vendas');
define('RW_FIN_EXPENSES','Despesas');
define('RW_FIN_NET_INCOME','Receita Líquida');

?>
