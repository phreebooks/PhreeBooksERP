<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreepos-pos_this_week
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/dashboards/pos_this_week/language/pt_br/language.php

define('CP_POS_THIS_WEEK_TITLE','Pos Sales This Week');
define('CP_POS_THIS_WEEK_DESCRIPTION','Lists the total of pos sales day by day from the beginning of the week. ');

?>
