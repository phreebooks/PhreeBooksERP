<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreepos-pos_todays
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/dashboards/pos_todays/language/pt_br/language.php

define('CP_POS_TODAYS_TITLE','Today\\\'s Pos Sales');
define('CP_POS_TODAYS_DESCRIPTION','Lists today\\\'s pos sales.');

?>
