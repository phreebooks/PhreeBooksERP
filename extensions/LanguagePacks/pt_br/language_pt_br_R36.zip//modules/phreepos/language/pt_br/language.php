<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreepos
// ISO Language: pt_br
// Version: 3.8
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/pt_br/language.php

define('PAYMENTS_RECEIVED','Pagamentos Recebidos:');
define('BNK_19_AMOUNT_PAID','Vlr. Recebido');
define('BOX_PHREEPOS_RETURN','Ponto de Venda - Retorno');
define('TEXT_ADD_UPDATE','Inserir/Alterar');
define('PHREEPOS_PAYMENT_TITLE','Entrar Pagamento');
define('TEXT_SUBTOTAL','Subtotal');
define('TEXT_AMOUNT_PAID','Valor Pago');
define('TEXT_BALANCE_DUE','Saldo Devedor');
define('TEXT_RETURN','Processar Retorno');
define('TEXT_DISCOUNT_AMOUNT','Vlr. Desconto.');
define('TEXT_DISCOUNT_PERCENT','Perc. Desconto');
define('TEXT_REFUND','Reembolso');
define('TEXT_REFUND_METHOD','Método Reembolso');
define('TEXT_ENTRIES','Lançamentos');
define('TEXT_SELECT_CUSTOMER','Selecionar  Cliente');
define('PHREEPOS_ITEM_NOTES','Cursor deve estar na caixa SKU para que o scanner de código de barra possa gravar a leitura.<br><b>ESC</b> = Limpar tela.<br><b>Alt+R</b> = Trocar entre  devoluções e vendas normais.<br><b>F7</b> = Mostrar inventário.<br><b>F8</b> = Mostrar cliente.<br><b>F9</b> = Mostrar pagamentos.');
define('PHREEPOS_PAYMENT_NOTES','<b>ESC</b> = Fechar pop-up.<br><b>F11</b>  = Salvar.<br><b>F12</b>  = Imprimir<br><b>seta up & down<b> = tipo pagamento diferente');
define('POS_MSG_DELETE_CONFIRM','Tem certeza de que quer cancelar/remover esta entrada POS?');
define('GENERAL_JOURNAL_19_ERROR_6','Uma venda POS não pode ser excluída se foi fechada!');
define('TEXT_TILL','Gaveta');
define('TEXT_PRINT_PREVIOUS','Imprimir Recibo Anterior');
define('TEXT_OPEN_DRAWER','Abrir Gaveta');
define('TEXT_AMOUNT_ORIGINAL_CURRENCY','Valor Original');
define('PHREEPOS_HANDELING_CASH_DIFFERENCE','Registrada diferença de caixa na gaveta');
define('TEXT_SALES','Vendas');
define('PAYMENTS_SHOULD_BE','Pagamentos Devem Ser');
define('NEW_BALANCE','Novo Saldo Gaveta');
define('POS_HEADING_CLOSING','Fechamento Dia');
define('TILL_BALANCE','Saldo Inicial Gaveta:');
define('TILL_END_BALANCE','Diferença');
define('TEXT_SHOW_COUNT_HELP','Mostrar auxílio contagem');
define('EXCEED_MAX_DISCOUNT','Você excedeu o desconto máximo de %s porcento.');
define('EXCEED_MAX_DISCOUNT_SKU','Você excedeu o desconto máximo de %s porcento para o SKU %s.');
define('OTHER_OPTIONS','Outras Opções');
define('POS_PRINT_OTHER','Imprimir Outro Recibo');
define('TEXT_CASH_IN','Entrada Caixa');
define('TEXT_CASH_OUT','Saída Caixa');
define('TEXT_EXPENSES','Despesas');
define('ERROR_NO_PAYMENT_METHODES','Não é possível abrir o POS porque não há métodos de pagamento definidos . Vá em empresas > módulo administração > módulo pagamentos e configure pagamentos para mostrar no POS e insira contas contábeis nos pagamentos
and set payments to show in pos and add gl accounts to payments');
define('TEXT_TYPE_OF_TRANSACTION','Tipo transação');

?>
