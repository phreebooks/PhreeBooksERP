<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreepos
// ISO Language: pt_br
// Version: 3.8
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/pt_br/menu.php

define('LANGUAGE','Portugues (BR)');
define('TITLE','EDS Brasil ERP');
define('TEXT_PHREEDOM_INFO','EDS Brasil Business Solutions');
define('HTML_PARAMS','lang=\\\"pt-BR\\\" xml:lang=\\\"pt-BR\\\"');
define('CHARSET','windows-1252');
define('MENU_HEADING_PHREEPOS','Ponto de Venda');
define('BOX_PHREEPOS','Ponto de Venda');
define('BOX_POS_CLOSING','Fechando PDV/PDC');
define('BOX_POS_MGR','PDV/PDC Gerenciador');
define('BOX_CUSTOMER_DEPOSITS','Depositos Clientes');
define('BOX_VENDOR_DEPOSITS','Depositos Fornecedores');

?>
