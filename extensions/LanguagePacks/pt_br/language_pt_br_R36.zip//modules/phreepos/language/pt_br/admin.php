<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreepos
// ISO Language: pt_br
// Version: 3.8
// +-----------------------------------------------------------------+
// Path: /modules/phreepos/language/pt_br/admin.php

define('MODULE_PHREEPOS_TITLE','PhreePOS Módulo');
define('BOX_PHREEPOS_ADMIN','Administração Ponto Venda');
define('TEXT_PHREEPOS_SETTINGS','PhreePOS Configurações Módulo');
define('MODULE_PHREEPOS_DESCRIPTION','O módulo PhreePOS provê uma interface de Ponto de Venda. Este módulo é um suplemento ao módulo Phreebooks e não é um substituto a ele.');
define('PHREEPOS_REQUIRE_ADDRESS_DESC','Solicitar informação de endereço para cada Venda POS/POP?');
define('PHREEPOS_RECEIPT_PRINTER_NAME_DESC','Defina o nome da impressora para imprimir recibos como definido nas preferências de impressora para a estação local.');
define('PHREEPOS_RECEIPT_PRINTER_STARTING_LINE_DESC','Aqui você pode inserir código para o cabeçalho do recibo.<br>Os códigos são números de chr isto é chr(13) é 13<br><b>Somente coloque os números. Texto pode resultar em erro.</b>Veja a documentação de sua impressora para ter os códigos corretos.');
define('PHREEPOS_RECEIPT_PRINTER_CLOSING_LINE_DESC','Aqui você insere código para abrir a gaveta e/ou cortar o recibo.<br>Separe os códigos com : e linhas com , como:<i>27:112:48:55:121,27:109</i><br>Os códigos são números de chr isto é chr(13) é 13<br><b>Somente coloque os números. Texto pode resultar em erro.</b>');
define('PHREEPOS_RECEIPT_PRINTER_OPEN_DRAWER_DESC','Aqui você pode incluir código para abrir a gaveta dependendo de pagamento (configure a opção de abertura de gaveta no módulo de pagamento).<br> Se um dos pagamentos selecionados tem a opção \\\\\\\'abrir gaveta\\\\\\\' selecionada a gaveta será aberta.<br>Separe os códigos com : e linhas com , como: <i>27:112:48:55:121,27:109</i><br>Os códigos são números de chr isto é chr(13) é 13<br><b>Somente coloque os números. Texto pode resultar em erro.</b>');
define('TEXT_EDIT_TILL','Editar Caixa');
define('TEXT_ENTER_NEW_TILL','Novo Caixa');
define('TEXT_ENTER_NEW_OTHER_TRANSACTION','Nova Outra Transação');
define('TEXT_TILLS','Caixas');
define('SETUP_TILL_DELETE_INTRO','Você quer remover este caixa?');
define('TEXT_EDIT_OTHER_TRANSACTION','Editar Outra Transação');
define('SETUP_OT_DELETE_INTRO','Você quer remover esta transação?');
define('PHREEPOS_DISPLAY_WITH_TAX_DESC','Você quer mostrar os preços na tela com impostos<br> (se você selecionou NÃO preços serão mostrados sem impostos)');
define('PHREEPOS_DISCOUNT_OF_DESC','Você quer que o desconto seja calculado sobre o total<br> ( se você selecionou NÃO então o desconto será calculado sobre o subtotal) ');
define('TEXT_NEUTRAL','Neutro');
define('TEXT_10_CENTS','10 Centavos');
define('TEXT_INTEGER','Inteiro');
define('PHREEPOS_ROUNDING_DESC','Como você quer que o total final seja arredondado.<br> <b>NÃO</b> significa que o total final não será arredondado.<br><b>INTEGER</b> significa: para o benefício do cliente tudo que for menor que 1 será ignorado.<br><b>10 CENTAVOS</b> significa: para o benefício do cliente tudo que for menor que 1 será ignorado.<br><b>NEUTRO</b> será arredondado para a fração  0, 5 or 10 centavos mais próximas (1,2,6,7 para baixo 3,4,8,9 para cima)');
define('TEXT_GL_ACCOUNT_ROUNDING','Conta Contábil para arredondamento de:');
define('TEXT_ROUNDING_OF','Arredondamento');
define('TEXT_RESTRICT_CURRENCY','Restringir a gaveta a esta moeda');
define('TEXT_DIF_GL_ACCOUNT','Conta Contábil para diferenças de final de dia::');
define('TEXT_DRAWER_CODES','códigos de abertura de gaveta');
define('TEXT_MAX_DISCOUNT','defina o valor máximo de desconto que pode ser dado nesta gaveta. Isto enão inclui os descontos definidos nas listas de preços.<br> deixe em branco se não quiser utilizar');
define('TEXT_TAX','imposto padrão');
define('TEXT_PHREEPOS_TRANSACTION_TYPE','Selecione o tipo de transação');
define('TEXT_OTHER_TRANS','Outras Transações');
define('TEXT_USE_TAX','Pode ser taxado');

?>
