<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreedom-audit_log
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/audit_log/language/pt_br/language.php

define('CP_AUDIT_LOG_TITLE','Audit Log');
define('CP_AUDIT_LOG_DESCRIPTION','Lists the audit log for a specific day.  The module has a control to set the day for which to display the log entries.');
define('CP_AUDIT_LOG_DISPLAY','Display entries ');
define('CP_AUDIT_LOG_DISPLAY2','day(s) back (Today=0)');

?>
