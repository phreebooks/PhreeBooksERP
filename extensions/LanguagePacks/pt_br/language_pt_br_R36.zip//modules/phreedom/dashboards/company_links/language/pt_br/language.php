<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreedom-company_links
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_links/language/pt_br/language.php

define('CP_COMPANY_LINKS_TITLE','Company Links');
define('CP_COMPANY_LINKS_DESCRIPTION','Lists URLs for all users as company wide links. ');

?>
