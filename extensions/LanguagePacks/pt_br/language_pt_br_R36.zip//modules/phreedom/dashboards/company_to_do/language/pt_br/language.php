<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreedom-company_to_do
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_to_do/language/pt_br/language.php

define('CP_COMPANY_TO_DO_TITLE','Company ToDo List');
define('CP_COMPANY_TO_DO_DESCRIPTION','Creates a list of activities and things to do viewable throughout the company.');

?>
