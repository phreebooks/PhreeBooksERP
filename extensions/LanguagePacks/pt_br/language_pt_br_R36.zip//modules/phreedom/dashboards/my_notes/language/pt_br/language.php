<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreedom-my_notes
// ISO Language: pt_br
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/my_notes/language/pt_br/language.php

define('CP_MY_NOTES_TITLE','My Notes');
define('CP_MY_NOTES_DESCRIPTION','Allows posting notes and reminders.');

?>
