<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreedom-todays_audit_log
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/todays_audit_log/language/pt_br/language.php

define('CP_TODAYS_AUDIT_LOG_TITLE','Today\\\'s Audit Log');
define('CP_TODAYS_AUDIT_LOG_DESCRIPTION','Lists today\\\'s audit log');

?>
