<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreedom-company_notes
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreedom/dashboards/company_notes/language/pt_br/language.php

define('CP_COMPANY_NOTES_TITLE','Company Notes');
define('CP_COMPANY_NOTES_DESCRIPTION','Allows posting notes and reminders viewable to all in company.');

?>
