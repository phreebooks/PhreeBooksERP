<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: contacts
// ISO Language: pt_br
// Version: 3.71
// +-----------------------------------------------------------------+
// Path: /modules/contacts/language/pt_br/ori_pt_br/menu.php

define('MENU_HEADING_CUSTOMERS','Clientes');
define('MENU_HEADING_VENDORS','Fornecedores');
define('BOX_PHREECRM_MODULE','PhreeCRM');
define('BOX_CONTACTS_NEW_BRANCH','Nova Filial');
define('BOX_CONTACTS_MAINTAIN_BRANCHES','Filial');
define('BOX_CONTACTS_NEW_CUSTOMER','Novo Cliente');
define('BOX_CONTACTS_MAINTAIN_CUSTOMERS','Clientes');
define('MENU_HEADING_EMPLOYEES','Funcion');
define('BOX_CONTACTS_NEW_EMPLOYEE','Novo Funcion');
define('BOX_CONTACTS_MAINTAIN_EMPLOYEES','Funcion');
define('BOX_CONTACTS_NEW_PROJECT','Novo Projeto');
define('BOX_CONTACTS_MAINTAIN_PROJECTS','Projetos');
define('BOX_CONTACTS_NEW_VENDOR','Novo Fornecedor');
define('BOX_CONTACTS_MAINTAIN_VENDORS','Fornecedores');
define('BOX_CONTACTS_NEW_CONTACT','Novo Contato');
define('BOX_HR_DEPARTMENTS','Departamentos');
define('BOX_PROJECTS_PHASES','Fases Projeto');
define('BOX_PROJECTS_COSTS','Custos Projeto');

?>
