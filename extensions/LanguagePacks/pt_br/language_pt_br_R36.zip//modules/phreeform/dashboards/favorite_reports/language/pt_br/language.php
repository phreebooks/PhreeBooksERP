<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreeform-favorite_reports
// ISO Language: pt_br
// Version: 0.1
// +-----------------------------------------------------------------+
// Path: /modules/phreeform/dashboards/favorite_reports/language/pt_br/language.php

define('CP_FAVORITE_REPORTS_TITLE','Favorite Reports');
define('CP_FAVORITE_REPORTS_DESCRIPTION','Lists favorite reports for quick display.');

?>
