<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: xml_builder
// ISO Language: pt_br
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/xml_builder/language/pt_br/language.php

define('XML_BUILDER_PAGE_TITLE','Módulo Gerador XML');

?>
