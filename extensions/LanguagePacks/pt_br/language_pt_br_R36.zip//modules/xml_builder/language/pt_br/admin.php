<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: xml_builder
// ISO Language: pt_br
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/xml_builder/language/pt_br/admin.php

define('MODULE_XML_BUILDER_TITLE','Gerador XML');
define('MODULE_XML_BUILDER_DESCRIPTION','Este módulo gera os arquivos de informação XML.');

?>
