<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreehelp
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/pt_br/admin.php

define('MODULE_PHREEHELP_TITLE','PhreeHelp Module');
define('MODULE_PHREEHELP_DESCRIPTION','The PhreeHelp module provides a popup context help screen to display manual entries supplied with modules. <b>NOTE: This is a core module and should not be removed!</b>');

?>
