<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: phreehelp
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/phreehelp/language/pt_br/language.php

define('HEADING_TITLE','Phreedom Help - Powered by PhreeHelp');
define('HEADING_CONTENTS','Contents');
define('HEADING_INDEX','Index');
define('TEXT_DOCUMENT','Document');
define('TEXT_EXIT','Exit');
define('TEXT_FOLDER','Folder');
define('TEXT_FORWARD','Forward');
define('TEXT_SUPPORT','PhreeSoft Online Support');
define('TEXT_KEYWORD','Type in the keyword to find:');
define('TEXT_SEARCH_RESULTS','Your search results:');
define('TEXT_UNTITLED','Untitled Document');
define('TEXT_MANUAL','Manual');
define('TEXT_NO_RESULTS','No results were found. The search word must be at least four letters and not a common word.');

?>
