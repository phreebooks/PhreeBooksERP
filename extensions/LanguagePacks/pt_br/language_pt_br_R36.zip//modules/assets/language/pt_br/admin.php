<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: assets
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/pt_br/admin.php

define('MODULE_ASSETS_TITLE','Módulo Ativos');
define('MODULE_ASSETS_DESCRIPTION','O módulo de ativos mantém um registro das propriedades da empresa. O módulo permite a criação de abas adicionais e campos para atender a necessidades do usuário.');
define('BOX_ASSETS_ADMIN','Administração Módulo Ativos');
define('TEXT_NEW_USED','Novo/Usado');
define('TEXT_EDIT_FIELD','Editar Campo Ativo');
define('TEXT_NEW_TAB','Aba Novo Ativo');
define('TEXT_EDIT_TAB','Editar Aba Ativo');
define('TEXT_NEW_FIELD','Novo Campo');

?>
