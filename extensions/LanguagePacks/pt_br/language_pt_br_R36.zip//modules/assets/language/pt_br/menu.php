<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: assets
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/pt_br/menu.php

define('BOX_ASSET_MODULE','Gerenciamento de Ativos');
define('MENU_HEADING_ASSETS','Ativos');

?>
