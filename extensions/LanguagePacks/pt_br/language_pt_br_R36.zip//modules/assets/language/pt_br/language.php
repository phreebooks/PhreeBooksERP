<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: assets
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/assets/language/pt_br/language.php

define('TEXT_ACQ_DATE','Data Aquisição');
define('TEXT_BUILDING','Construções');
define('TEXT_COMPUTER','Computadores');
define('TEXT_ASSET_ID','Ativo ID');
define('TEXT_ASSETS','ativos');
define('TEXT_CONDITION','Condição');
define('TEXT_DESCRIPTION_SHORT','Descrição Curta');
define('TEXT_FURNITURE','Móveis');
define('TEXT_EQUIP','Ferramentas e Equipamentos');
define('TEXT_DETAIL_DESCRIPTION','Descrição Detalhada');
define('TEXT_IMAGE','Imagem');
define('TEXT_RETIRE_DATE','Data Retirada');
define('TEXT_LAND','Terrenos');
define('TEXT_SOFTWARE','Software');
define('TEXT_TABS','Abas');
define('TEXT_USED','Utilizado');
define('TEXT_VEHICLE','Veículos');
define('','****');
define('ASSETS_ENTER_ASSET_ID','Criar um Novo Ativo');
define('ASSETS_ENTRY_ASSETS_TYPE','Tipo Ativo');
define('ASSETS_ENTRY_ASSET_TYPE','Entre o Tipo de Ativo');
define('ASSETS_ENTRY_FULL_PRICE','Custo Original');
define('ASSETS_ENTRY_ACCT_SALES','Conta Contábil Ativos');
define('ASSETS_ENTRY_ACCT_INV','Conta Contábil Depreciação');
define('ASSETS_ENTRY_ACCT_COS','Conta Contábil Manutenção');
define('ASSETS_ENTRY_ASSETS_SERIALIZE','Fabricante/Modelo/VIN');
define('ASSETS_DATE_ACCOUNT_CREATION','Data Aquisição Ativo');
define('ASSETS_DATE_LAST_JOURNAL_DATE','Data Retirada Ativo');
define('ASSETS_DATE_LAST_UPDATE','Data Última Manutenção');
define('ASSETS_ENTRY_IMAGE_PATH','Caminho Relativo Imagem');
define('ASSETS_MSG_COPY_INTRO','Entre o ID do Ativo para o novo ativo');
define('ASSETS_PURCHASE_CONDITION','Condição Aquisição');
define('ASSETS_MSG_RENAME_INTRO','Entre o ID do Ativo para renomear o novo ativo');

?>
