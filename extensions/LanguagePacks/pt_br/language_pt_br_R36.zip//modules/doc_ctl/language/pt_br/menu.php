<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: doc_ctl
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/pt_br/menu.php

define('MENU_HEADING_QUALITY','Qualidade');
define('BOX_DOC_CTL_MODULE','Controle Documentos');

?>
