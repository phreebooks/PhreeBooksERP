<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: doc_ctl
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/pt_br/language.php

define('TEXT_BOOKMARK_DOC','Marcar Documentos');
define('TEXT_BOOKMARKED','Marcas');
define('TEXT_CANCEL_CHECKOUT','Cancelar Sinal de Saída');
define('TEXT_CHECKED_OUT','Despachado');
define('TEXT_CHECKOUT_DOC','Despachar Documento');
define('TEXT_CREATE_DATE','Data Criação');
define('TEXT_DETAILS','Detalhes');
define('TEXT_DOCUMENT','Documento: ');
define('TEXT_DOCUMENT_TITLE','Conteúdo de:');
define('TEXT_DOCUMENTS','Lista Documentos');
define('TEXT_DOWNLOAD_DOCUMENT','Baixa Documentos');
define('TEXT_FILENAME','Nome Arquivo');
define('TEXT_IMG_NOT_AVAILABLE','Imagem Não Disponível');
define('TEXT_LAST_UPDATE','Última Atualização');
define('TEXT_LAST_VIEW','Última Visualização');
define('TEXT_LOCK_DOC','Travar Documento');
define('TEXT_LOCKED','Travado');
define('TEXT_MY_BOOKMARKS','Minhas Marcas');
define('TEXT_MY_CHECKED_OUT','Arquivos Despachados');
define('TEXT_NEW_FOLDER','Nova Pasta');
define('TEXT_NEW_DOCUMENT','Novo Documento');
define('TEXT_NO_BOOKMARKS','Não foram colocadas marcas.');
define('TEXT_NO_CHECKED_OUT','Não foram encontrados Arquivos Despachados.');
define('TEXT_NO_DOCUMENTS','Não foram encontrados Documentos.');
define('TEXT_OWNER','Proprietário');
define('TEXT_PATH','Caminho');
define('TEXT_RECENTLY_ADDED','Documentos Recentemente Adicionados');
define('TEXT_REMOVE_BOOKMARK','Remover Marca');
define('TEXT_REVISION','Revisão');
define('TEXT_THUMBNAIL','Thumbnail');
define('TEXT_UNLOCK_DOC','Destravar Documento');
define('TEXT_UPLOAD_FILE','Carregar Revisão');
define('DOC_CTL_EMPTY_FOLDER','A pasta não contém nenhum documento.');
define('DOC_CTL_FILE_WRITE_ERROR','Houve um erro ao gravar o arquivo. Verifique as permissões da pasta (%s) e tente novamente.');
define('DOC_CTL_ITEMS','Pastas e Documentos');
define('DOC_CTL_DELETE_DOCUMENT','Tem certeza de que quer remover este documento?');
define('DOC_CTL_DELETE_DIRECTORY','Tem certeza de que quer remover esta pasta?');
define('DOC_CTL_JS_DEL_BOOKMARK','Are you sure you want to \',\'Tem certeza de que quer ');
define('DOC_CTL_JS_DIR_DELETED_ERROR','Esta pasta não está vazia, não pode ser removida!');

?>
