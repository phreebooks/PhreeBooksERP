<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: doc_ctl
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/doc_ctl/language/pt_br/admin.php

define('MODULE_DOC_CTL_TITLE','Módulo Controle Documentos');
define('MODULE_DOC_CTL_DESCRIPTION','O módulo de Controle de Documentos provê um sistema de gerenciamento de documentos para controlar vários tipos de documentos. Este módulo inclui funções para entrada/saída de documentos, travar para edição, segurança e gerenciamento de estrutura de pastas.');
define('TEXT_DRIVE','Drive');

?>
