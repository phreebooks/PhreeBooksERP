<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: bulk_inv
// ISO Language: pt_br
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/bulk_inv/language/pt_br/admin.php

define('MODULE_BULK_INV_TITLE','Ferramenta de Inventário em Lote');
define('MODULE_BULK_INV_DESCRIPTION','Esta ferramenta auxilia a entrada de informação na base de dados de forma mais rápida que o Gerenciador de Inventário normal.');

?>
