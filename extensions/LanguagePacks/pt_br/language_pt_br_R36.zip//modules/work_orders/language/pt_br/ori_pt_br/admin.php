<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: work_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/work_orders/language/pt_br/ori_pt_br/admin.php

define('NEXT_WO_NUM_DESC','Next Work Order Number');
define('TEXT_WORK_ORDER_FORMS','Work Order Forms');
define('MODULE_WORK_ORDERS_DESCRIPTION','The Work Order module provides a complete inventory production control system. This module interacts with the Inventory module to control the build process and help manage inventory.');
define('MODULE_WORK_ORDERS_TITLE','Work Order Module');

?>
