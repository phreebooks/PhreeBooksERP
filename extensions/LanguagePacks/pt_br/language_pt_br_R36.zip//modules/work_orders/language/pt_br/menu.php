<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: work_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/work_orders/language/pt_br/menu.php

define('MENU_HEADING_WORK_ORDERS','Ordens Serviço');
define('BOX_WORK_ORDERS_BUILDER','Gerador Ordem Serviço');
define('BOX_WORK_ORDERS_MODULE','Gerenciador Ordem Serviço');
define('BOX_WORK_ORDERS_MODULE_TASK','Tarefas Ordem Serviço');

?>
