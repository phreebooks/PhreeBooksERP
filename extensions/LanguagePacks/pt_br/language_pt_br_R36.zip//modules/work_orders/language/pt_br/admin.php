<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: work_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/work_orders/language/pt_br/admin.php

define('MODULE_WORK_ORDERS_TITLE','Módulo Ordem Serviço');
define('MODULE_WORK_ORDERS_DESCRIPTION','O módulo Ordem Serviço provê um sistema completo para o controle de produção de inventário. Este sistema interage com o módulo de Inventário para controlar o processo de montagem e auxiliar a gerenciar o inventário.');
define('NEXT_WO_NUM_DESC','Número Próxima Ordem Serviço');
define('TEXT_WORK_ORDER_FORMS','Formulários Ordem Serviço');

?>
