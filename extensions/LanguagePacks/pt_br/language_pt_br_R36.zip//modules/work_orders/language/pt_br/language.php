<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: work_orders
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/work_orders/language/pt_br/language.php

define('WORK_ORDER_MSG_DELETE_WO','Tem certeza de que quer');
define('WO_AUDIT_LOG_WO_COMPLETE','OS %s - Completada');
define('WO_AUDIT_LOG_STEP_COMPLETE','OS Passo %s - Completado');
define('WO_AUDIT_LOG_MAIN','OS Principal (%s) - ');
define('WO_AUDIT_LOG_TASK','OS Tarefa ($s) - ');
define('WO_TEXT_PARTS_SHORTAGE','(%s de %s) necessário do SKU %s - %s');
define('WO_TASK_ID_MISSING','ID Tarefa e Descrição são campos obrigatórios.');
define('WO_DUPLICATE_TASK_ID','O registro não foi alterado, uma ID Tarefa com este nome já existe no sistema!');
define('WO_ERROR_CANNOT_DELETE','A Tarefa de Ordem Serviço não pode ser removida porque está sendo utilizada em uma Ordem de Serviço. Veja a Ordem Serviço #');
define('WO_POPUP_TASK_WINDOW_TITLE','Tarefas Ordem Serviço');
define('WO_ROLL_REVISION','Esta Ordem Serviço foi utilizada pelo sistema, quaisquer alterações levarão a revisão ao próximo nível.');
define('HEADING_WORK_ORDER_MODULE_NEW','Criar Ordem Serviço');
define('TEXT_APPROVALS','Aprovações');
define('HEADING_WORK_ORDER_MODULE_BUILD','Gerar e Rastrear Ordem Serviço');
define('HEADING_WORK_ORDER_MODULE_EDIT','Editar Ordem Serviço');
define('TEXT_CLOSE_DATE','Data Fechamento');
define('TEXT_COMPLETE','Completado');
define('TEXT_BUILD','Gerar Ordem Serviço');
define('TEXT_DATA_ENTRY','Data Entrada');
define('TEXT_DOCUMENTS','Documentos Referência');
define('TEXT_DRAWINGS','Desenhos Referência');
define('TEXT_DAYS','Dias');
define('TEXT_ERP_ENTRY','ERP Entrada');
define('TEXT_HOURS','Horas');
define('TEXT_ENTRY_VALUE','Valor Entrada');
define('TEXT_MFG','Mfg');
define('TEXT_MINUTES','Minutos');
define('TEXT_NA','N/A');
define('TEXT_MFG_INIT','Mfg Sign-off');
define('TEXT_PRIORITY','Prioridade');
define('TEXT_PROCEDURE','Procedimento');
define('TEXT_QA','QA');
define('TEXT_QA_INIT','QA Sign-off');
define('TEXT_REVISION','Revisão');
define('TEXT_SPECIAL_NOTES','Notas e Comentários Ordem Serviço');
define('TEXT_TASK_DESC','Descrição Tarefa');
define('TEXT_TASKS','Tarefas');
define('TEXT_STEP','Passo');
define('TEXT_REVISION_DATE','Data Revisão');
define('TEXT_TASK_NAME','Nome Tarefa');
define('TEXT_TASK_SEQUENCE','Sequência Tarefa');
define('TEXT_TASK_STATUS','Situação Tarefa');
define('TEXT_TASK_TIME','Tempo Tarefa');
define('TEXT_WORK_ORDERS','Ordens Serviço');
define('TEXT_USE_ALLOCATION','Usar Alocação');
define('TEXT_WO_ID','ID Ordem Serviço');
define('TEXT_WORK_ORDERS_TASK','Tarefas Ordem Serviço');
define('TEXT_WO_HISTORY','Histórico (últimos %s resultados)');
define('TEXT_WO_TITLE','Título Ordem Serviço');
define('WO_MESSAGE_BUILDER_ERROR','Houve um erro ao incluir/alterar o registro da  Ordem Serviço. Por favor verifique e tente novamente.');
define('WO_BUILDER_ERROR_DUP_TITLE','O Título  Ordem Serviço já foi utilizado. Tente novamente!');
define('WO_ERROR_CANNOT_DELETE_BUILDER','Esta Ordem Serviço foi utilizada no sistema. Não pode ser removida.');
define('WO_MSG_COPY_INTRO','Por favor entre o Título para a nova Ordem Serviço.');
define('WO_SKU_NOT_FOUND','O SKU digitado não foi encontrado na tabela de Inventário.');
define('WO_INSUFFICIENT_INVENTORY','Não há peças suficientes para montar o SKU solicitado. As peças que faltam são:');
define('WO_MESSAGE_SUCCESS_MAIN_UPDATE','O registro da  Ordem Serviço foi incluído com sucesso!');
define('WO_MESSAGE_SUCCESS_MAIN_ADD','O registro da  Ordem Serviço foi alterado com sucesso!');
define('WO_MESSAGE_SUCCESS_MAIN_DELETE','A Ordem Serviço foi removida com sucesso!');
define('WO_MESSAGE_STEP_UPDATE_SUCCESS','Passo %s Ordem Serviço foi completado com sucesso.');
define('WO_MESSAGE_MAIN_ERROR','Houve um erro ao incluir/alterar o registro da  Ordem Serviço. Por favor verifique e tente novamente.');
define('WO_MESSAGE_SUCCESS_COMPLETE','Ordem Serviço %s foi completada com sucesso.');
define('WO_MFG_PASSWORD_BAD','A senha de acesso de fabricação não coincide com o nome do usuário.');
define('WO_QA_PASSWORD_BAD','A senha de acesso de qualidade garantida não coincide com o nome do usuário.');
define('WO_DB_UPDATE_ERROR','Houve um erro ao atualizar a base de dados.');
define('WO_DATA_VALUE_BLANK','Uma informação é necessária mas foi deixada em branco.');
define('WO_MESSAGE_SUCCESS_UPDATE','A Ordem Serviço foi alterada com sucesso!');
define('WO_MESSAGE_SUCCESS_ADD','A Ordem Serviço foi incluída com sucesso!');
define('WO_SKU_ID_REQUIRED','O SKU e o Título Ordem Serviço são campos obrigatórios.');
define('WO_MESSAGE_ERROR','There was and error adding/updating the work order task. Please check the data and retry.');
define('WO_CANNOT_SAVE','Esta Ordem Serviço tem uma revisão mais atual, alterações não podem ser gravadas.');

?>
