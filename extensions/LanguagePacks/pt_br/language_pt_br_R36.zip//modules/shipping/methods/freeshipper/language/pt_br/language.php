<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: shipping-freeshipper
// ISO Language: pt_br
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/freeshipper/language/pt_br/language.php

define('MODULE_SHIPPING_FREESHIPPER_TEXT_TITLE','FREE SHIPPING!');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_SHORT','Free Shipping');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_DESCRIPTION','FREE SHIPPING');
define('MODULE_SHIPPING_FREESHIPPER_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_FREESHIPPER_COST_DESC','What is the Shipping cost?');
define('MODULE_SHIPPING_FREESHIPPER_HANDLING_DESC','Handling fee for this shipping method.');
define('MODULE_SHIPPING_FREESHIPPER_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('freeshipper_1DEam','Best Way');
define('freeshipper_1Dam','Sender Paid 2 Day');
define('freeshipper_1Dpm','Sender Paid 1 Day');
define('freeshipper_2Dpm','Courier');
define('freeshipper_3Dpm','Sender Paid Economy');
define('freeshipper_GND','Local Delivery');
define('freeshipper_GDR','Customer Pickup');
define('SHIPPING_FREESHIPPER_SHIPMENTS_ON','Free Shipping Shipments on ');

?>
