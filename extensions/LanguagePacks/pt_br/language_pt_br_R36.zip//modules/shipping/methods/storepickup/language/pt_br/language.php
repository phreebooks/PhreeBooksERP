<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: shipping-storepickup
// ISO Language: pt_br
// Version: 3.2
// +-----------------------------------------------------------------+
// Path: /modules/shipping/methods/storepickup/language/pt_br/language.php

define('MODULE_SHIPPING_STOREPICKUP_TEXT_TITLE','Store Pickup');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_SHORT','Store Pickup');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_DESCRIPTION','Customer In Store Pick-up');
define('MODULE_SHIPPING_STOREPICKUP_STATUS_DESC','Do you want to offer In Store rate shipping?');
define('MODULE_SHIPPING_STOREPICKUP_TITLE_DESC','Title to use for display purposes on shipping rate estimator');
define('MODULE_SHIPPING_STOREPICKUP_COST_DESC','The shipping cost for all orders using this shipping method.');
define('MODULE_SHIPPING_STOREPICKUP_SORT_ORDER_DESC','Sort order of display. Determines the order which this method appears on all generted lists.');
define('storepickup_GND','Store Pickup');
define('SHIPPING_STOREPICKUP_SHIPMENTS_ON','Store Pickup Shipments on ');

?>
