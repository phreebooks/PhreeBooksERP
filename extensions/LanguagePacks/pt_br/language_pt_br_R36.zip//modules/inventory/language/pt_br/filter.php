<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: inventory
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/inventory/language/pt_br/filter.php

define('FILTER_TABEL_HEAD_VALUE','Valor: ');
define('FILTER_TABEL_HEAD_COPAIRISON','Compara');
define('FILTER_TABEL_HEAD_FIELD','Campo: ');
define('FILTER_LESS_THAN','Menor que: ');
define('FILTER_CONTAINS','Cont');
define('FILTER_BIGGER_THAN','Maior que: ');
define('FILTER_NOT_LIKE','N');
define('FILTER_LIKE','Parecido com: ');
define('FILTER_NOT_EQUAL_TO','Diferente de: ');
define('FILTER_EQUAL_TO','Igual A: ');

?>
