<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: cp_action
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/cp_action/language/pt_br/admin.php

define('NEXT_CAPA_NUM_DESC','Próximo Número Ação Corretiva/Preventiva');
define('MODULE_CP_ACTION_TITLE','Módulo AC/AP');
define('MODULE_CP_ACTION_DESCRIPTION','O módulo de ação COrretiva/Preventiva é utilizado como parte de um sistema de controle de qualidade interno para registrar, rastrear e monitorar problemas no processo organizacional da empresa.');

?>
