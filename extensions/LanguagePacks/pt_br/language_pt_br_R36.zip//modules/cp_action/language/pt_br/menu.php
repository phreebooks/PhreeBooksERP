<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: cp_action
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/cp_action/language/pt_br/menu.php

define('BOX_CAPA_MODULE','C/P Ação');
define('MENU_HEADING_CAPA','Ação Corretiva/Preventiva');
define('MENU_HEADING_QUALITY','Qualidade');

?>
