<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: import_bank
// ISO Language: pt_br
// Version: 2
// +-----------------------------------------------------------------+
// Path: /modules/import_bank/language/pt_br/language.php

define('GENERAL_JOURNAL_7_DESC','Aviso Crédito');
define('TEXT_BIMP_ERMSG5','não há conta contábil com a descrição:  ');
define('TEXT_BIMP_ERMSG4','há duas ou mais contas com a mesma conta bancária : ');
define('TEXT_BIMP_ERMSG3','a outra conta bancária está vazia');
define('TEXT_BIMP_ERMSG2','há duas ou mais contas contábeis com a descrição : ');
define('TEXT_REQUIRED','OBRIGATÓRIO');
define('TEXT_BIMP_ERMSG1','conta bancária está vazia');
define('SAMPLE_CSV','Exemplo CSV');
define('TEXT_IMPORT','Importar');
define('GEN_BANK_IMPORT_MESSAGE','Selecione o arquivo .csv e tecle Importar <br> Se não há uma coluna conta bancária no seu .csv então selecione uma conta bancária na caixa de seleção.');
define('HEADING_MODULE_IMPORT_BANK','Importar lançamentos bancários');
define('MODULE_IMPORT_BANK_TITLE','Importar lançamentos bancários');
define('TEXT_NEW_BANK','Encontrado um novo número de banco. Você pode incluir Número Banco = %s no Contato = %s ');
define('TEXT_NEW_IBAN','Encontrado um novo número de  IBAN. Você pode incluir Iban = %s no Contato = %s ');

?>
