<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: import_bank
// ISO Language: pt_br
// Version: 2
// +-----------------------------------------------------------------+
// Path: /modules/import_bank/language/pt_br/admin.php

define('TEXT_ENTER_TRANSACTION','Entre modelo para nova transação');
define('IMPORT_BANK_CONFIG_SAVED','configuração de import_bank gravada');
define('TEXT_BANK_ACCOUNT','Conta bancária ou IBAN');
define('BANK_IMPORT_DEBIT_CREDIT','A descrição quando valores são creditados em sua conta <br> <B> isto é para o campo debit_credit no xml</B>');
define('BANK_IMPORT_QUESTION_POSTS','Para assgurar que os registros não são lançados pelo script como ultima alternativa os lançamentos são armazenados nos itens em dúvida do diário<B> Isto deve ser preenchido ou o script não funcionará</B>');
define('TEXT_BANK_IMPORT_SETTINGS','Configurações De Importação de Bancos');
define('MODULE_BANK_IMPORT_CONFIG_INFO','Por favor, entre sua configuração');
define('BOX_BANK_IMPORT_ADMIN','Configurações De Importação de Bancos');
define('MODULE_IMPORT_BANK_DESCRIPTION','Com este módulo você pode importar lançamentos bancários em formato .csv. Esta lista é verificada contra todas as contas pendentes ou lançamentos prévios com a mesma descrição.');
define('MODULE_IMPORT_BANK_TITLE','Importar lançamentos bancários');
define('TEXT_EDIT_TRANSACTION','Editar modelo de transação');
define('TEXT_KNOWN_TRANSACTION','Modelo de Transação');

?>
