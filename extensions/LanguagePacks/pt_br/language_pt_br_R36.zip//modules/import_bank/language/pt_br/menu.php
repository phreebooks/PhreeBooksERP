<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: import_bank
// ISO Language: pt_br
// Version: 2
// +-----------------------------------------------------------------+
// Path: /modules/import_bank/language/pt_br/menu.php

define('BOX_IMPORT_BANK_MODULE','Importar lançamentos bancários');

?>
