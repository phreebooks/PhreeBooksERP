<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: sku_pricer
// ISO Language: pt_br
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/pt_br/admin.php

define('MODULE_SKU_PRICER_TITLE','SKU Valores');
define('MODULE_SKU_PRICER_DESCRIPTION','Este módulo vai atualizar o preço cheio e o custo de um determinado SKU  a partir de um arquivo CSV.');

?>
