<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: sku_pricer
// ISO Language: pt_br
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/pt_br/menu.php

define('BOX_SKU_PRICER_TITLE','SKU Valores');

?>
