<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: sku_pricer
// ISO Language: pt_br
// Version: 1.0
// +-----------------------------------------------------------------+
// Path: /modules/sku_pricer/language/pt_br/language.php

define('SKU_PRICER_PAGE_TITLE','SKU Importar Valores');
define('SKU_PRICER_SELECT','Por favor selecione o arquivo CSV para importar.');
define('SKU_PRICER_DIRECTIONS','Depois que um arquivo oi selecionado, pressione o ícone Salvar para executar o scriptt.<br />O formato do arquivo (com cabeçalho):<br />sku,custo,preço,código_upc<br>SKU_NUM,2.00, 4.00, upc<br />Números reais com ponto como decimal, sem símbolos ou outros caracteres.');

?>
