<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment-moneyorder
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/moneyorder/language/pt_br/language.php

define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE','Check/Money Order');
define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION','Payments via check, money order, EFT and other direct forms of payment not requiring a payment gateway.');
define('MODULE_PAYMENT_MONEYORDER_TEXT_INTRODUCTION','Please make your check or money order payable to:<br />\' . MODULE_PAYMENT_MONEYORDER_PAYTO . \'<br />Mail your payment to:<br />');
define('MODULE_PAYMENT_MONEYORDER_TEXT_REF_NUM','Reference Number');
define('MODULE_PAYMENT_MONEYORDER_PAYTO_DESC','Make Payments To:');

?>
