<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment-directdebit
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/directdebit/language/pt_br/language.php

define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_TITLE','Direct Debits');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_DESCRIPTION','Direct Debit and Electronic Funds Transfer (EFT) Payments.');
define('MODULE_PAYMENT_DIRECTDEBIT_TEXT_REF_NUM','Reference Number');

?>
