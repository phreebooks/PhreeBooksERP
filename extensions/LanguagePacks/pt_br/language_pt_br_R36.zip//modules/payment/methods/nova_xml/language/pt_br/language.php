<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment-nova_xml
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/nova_xml/language/pt_br/language.php

define('MODULE_PAYMENT_NOVA_XML_TEXT_TITLE','Elevon');
define('MODULE_PAYMENT_NOVA_XML_TEXT_DESCRIPTION','Accept credit card payments through the Elevon payment gateway');
define('MODULE_PAYMENT_NOVA_XML_TEXT_INTRODUCTION','When in test mode, cards return a success code but are not processed.');
define('MODULE_PAYMENT_NOVA_XML_STATUS_DESC','Do you want to accept Elevon Network payments ?');
define('MODULE_PAYMENT_NOVA_XML_MERCHANT_ID_DESC','The Elevon Merchant ID used for the Elevon Network service:');
define('MODULE_PAYMENT_NOVA_XML_USER_ID_DESC','The Elevon User ID used for the Elevon Network service:');
define('MODULE_PAYMENT_NOVA_XML_PIN_DESC','PIN used for the Elevon Network service:');
define('MODULE_PAYMENT_NOVA_XML_TESTMODE_DESC','Transaction mode used for processing orders');
define('MODULE_PAYMENT_NOVA_XML_AUTHORIZATION_TYPE_DESC','Do you want submitted credit card transactions to be authorized only, or authorized and captured?');

?>
