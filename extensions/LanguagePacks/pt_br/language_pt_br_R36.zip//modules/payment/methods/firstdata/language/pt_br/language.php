<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment-firstdata
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/firstdata/language/pt_br/language.php

define('MODULE_PAYMENT_FIRSTDATA_TEXT_TITLE','FirstData Gateway');
define('MODULE_PAYMENT_FIRSTDATA_TEXT_DESCRIPTION','Accept credit card payments through the FirstData Global payment gateway');
define('MODULE_PAYMENT_FIRSTDATA_TEXT_INTRODUCTION','When in test mode, cards return an Approved code but are not processed.<br /><br />');
define('MODULE_PAYMENT_FIRSTDATA_CONFIG_FILE_DESC','The Store ID used for the FirstData Network service.');
define('MODULE_PAYMENT_FIRSTDATA_KEY_FILE_DESC','The PEM key file with path used for the FirstData Network service. File must be placed in the directory modules/firstdata. Typipcally the store ID with the .pem extension.');
define('MODULE_PAYMENT_FIRSTDATA_HOST_DESC','The host used for the FirstData Network service. Provided in welcome packet. Should be something like: https://secure.linkpt.net');
define('MODULE_PAYMENT_FIRSTDATA_PORT_DESC','The port used for the FirstData Network service. Provided in welcome packet.');
define('MODULE_PAYMENT_FIRSTDATA_TESTMODE_DESC','Transaction mode used for processing orders');
define('MODULE_PAYMENT_FIRSTDATA_AUTHORIZATION_TYPE_DESC','Do you want submitted credit card transactions to be authorized only, or authorized and captured?');

?>
