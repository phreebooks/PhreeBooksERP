<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment-cod
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/cod/language/pt_br/language.php

define('MODULE_PAYMENT_COD_TEXT_TITLE','Cash on Delivery');
define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION','Cash on Delivery');

?>
