<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment-freecharger
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/payment/methods/freecharger/language/pt_br/language.php

define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE','Free Payment');
define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION','Free payment method for use with purchases requiring no payment.');

?>
