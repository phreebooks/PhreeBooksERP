<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: payment
// ISO Language: pt_br
// Version: 3.6
// +-----------------------------------------------------------------+
// Path: /modules/payment/language/pt_br/admin.php

define('MODULE_PAYMENT_TITLE','Módulo Pagamento');
define('MODULE_PAYMENT_DESCRIPTION','O Módulo Pagamento permite configurar métodos de pagamento. SAlguns métodos são incluídos na instalação e outros estão disponpiveis para download no website PhreeSoft. <b>ATENÇÃO: Este é um módulo central e não deve ser removido!</b>');
define('TEXT_PAYMENT_MODULES_AVAILABLE','Métodos de Pagamento Disponíveis');
define('TEXT_PRODUCTION','Produção');
define('TEXT_AUTHORIZE','Autorizar');
define('TEXT_CAPTURE','Capturar');
define('TEXT_REMOVE_MESSAGE','Tem certeza de que quer remover este módulo e todos os dados associados com ele?');
define('OPEN_POS_DRAWER_DESC','Permite a abertura da gaveta do PDV quando o pagamento é selecionado.');
define('OPEN_POS_DRAWER','0');
define('SORT_ORDER_DESC','Ordenar visualização. Mais baixo é mostrado antes.');
define('POS_GL_ACCT_DESC','PDV tipo conta pagamento');
define('SHOW_IN_POS_DESC','Mostrar este pagamento no PhreePOS');

?>
