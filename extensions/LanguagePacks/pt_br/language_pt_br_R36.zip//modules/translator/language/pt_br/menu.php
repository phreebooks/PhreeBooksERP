<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: translator
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/pt_br/menu.php

define('MENU_HEADING_TRANSLATOR','Ferramenta de Tradução De Idioma');
define('BOX_TRANSLATOR_MODULE','Assistente Tradução');

?>
