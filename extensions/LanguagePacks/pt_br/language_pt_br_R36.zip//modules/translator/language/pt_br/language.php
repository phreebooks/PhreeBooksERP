<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: translator
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/pt_br/language.php

define('BOX_TRANSLATOR_MAINTAIN','Assistente Tradução');
define('TEXT_NEW_TRANSLATION','Nova Tradução');
define('TEXT_IMPORT_TRANSLATION','Importar Tradução');
define('TEXT_EXPORT_TRANSLATION','Exportar Tradução');
define('TEXT_UPLOAD_TRANSLATION','Carregar Tradução');
define('TEXT_IMPORT_CURRENT_LANGUAGE','Importar da Instalação Atual');
define('TEXT_EXPORT_CURRENT_LANGUAGE','Exportar Tudo para um idioma e versão');
define('TEXT_UPLOAD_LANGUAGE_FILE','Carregar de um Arquivo Zipado');
define('TEXT_EDIT_TRANSLATION','Módulo Tradução');
define('TEXT_CHECK_ALL','Selecionar Todas as Caixas de Seleção');
define('TEXT_LANGUAGE','Idioma');
define('TEXT_LATEST','Última');
define('TEXT_UPLOAD','Carregar');
define('TEXT_LANGUAGE_CODE','Código Idioma ISO');
define('TEXT_TRANSLATION','Tradução');
define('TEXT_TRANSLATIONS','Traduções');
define('TEXT_TRANSLATED','Traduzido');
define('TEXT_CREATE_NEW_TRANSLATION','Criar Nova Tradução');
define('TRANSLATOR_NEW_DESC','Este formulário cria uma nova versão de tradução. Se você quer que dicas de tradução de versões anteriores sobrescrevam o idioma fonte o idioma deve também estar na base de dados de tradução. (Versão # será criado automaticamente)');
define('TRANSLATOR_NEW_SOURCE','Módulo Fonte:');
define('TEXT_SOURCE_LANGUAGE','Linguagem Fonte:');
define('TRANSLATOR_NEW_OVERRIDE','Então sobrescrever (se disponível) do idioma instalado:');
define('TRANSLATOR_IMPORT_DESC','Esta página importa idiomas carregados do módulo ou módulos atualmente instalados na base de dados de traduções. Se o módulo de instalação for selecionado e a pasta tiver sido renomeada, o novo diretório deve ser digitado no formulário abaixo.');
define('TRANSLATOR_EXPORT_DESC','Esta página exporta todos os módulos de um idioma e versão traduzidos para um único arquivo .zip.');
define('TRANSLATOR_ISO_IMPORT','Idioma ISO para importar (formato xx_xx):');
define('TRANSLATOR_ISO_EXPORT','Idioma ISO para exportar:');
define('TRANSLATOR_MODULE_IMPORT','Nome Módulo para importar:');
define('TRANSLATOR_INSTALL_IMPORT','Nome da pasta install (se movida após a instalação):');
define('TRANSLATOR_UPLOAD_DESC','Este formulário vai carregar um arquivo de idioma zipado e importar todas as definições na base de dados. Deve ser utilizado para auxiliar na conversão de versões antigas para novas ou na modificação de traduções para novos idiomas.');
define('TRANSLATOR_ISO_CREATE','Idioma ISO para criar (formato xx_xx):');
define('TRANSLATOR_MODULE_CREATE','Módulo para designar tradução:');
define('TRANSLATOR_RELEASE_CREATE','Número de versão a ser criado:');
define('TRANSLATOR_UPLOAD_ZIPFILE','Selecione um arquivo zipado para carregar e inserir na base de dados de traduções:');
define('MESSAGE_DELETE_TRANSLATION','Tem certeza de que quer remover esta tradução??');
define('TEXT_CONSTANT','Constante Definida');
define('TEXT_DEFAULT_TRANSLATION','Tradução Atual');
define('TEXT_STATS_VALUES','%s de %s traduzido (%s porcentual)');
define('TEXT_TRANSLATIONS_SAVED','Registros de tradução gravados.');
define('TRANSLATION_HEADER','Arquivo de Tradução de Idioma Phreedom');
define('TRANS_ERROR_NO_SOURCE','Não há versões disponíveis do idioma fonte! Por favor, importe o idioma fonte.');
define('','');

?>
