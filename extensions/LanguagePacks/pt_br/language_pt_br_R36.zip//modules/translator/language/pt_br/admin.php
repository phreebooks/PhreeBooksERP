<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:23
// Module/Method: translator
// ISO Language: pt_br
// Version: 3.3
// +-----------------------------------------------------------------+
// Path: /modules/translator/language/pt_br/admin.php

define('MODULE_TRANSLATOR_TITLE','Módulo Tradução');
define('MODULE_TRANSLATOR_DESCRIPTION','O módulo de Tradução provê uma interface conveniente para traduzir arquivos de idiomas de um idioma para outro. Este módulo trabalha com atualizações de versões bem como suporte completo a uma nova tradução.');

?>
