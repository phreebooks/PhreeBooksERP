<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: audit
// ISO Language: pt_br
// Version: 1
// +-----------------------------------------------------------------+
// Path: /modules/audit/language/pt_br/language.php

define('TEXT_EXCLUDE','excluir');
define('TEXT_ALL_OR_ACTIVE','Você quer exportar tudo ou tudo excluindo ordens, cotações e itens aguardando faturamento');
define('GL_ERROR_BALANCE','As Contas Contábeis estão fora de balanço');
define('TEXT_BALANCE_SHEET','Balancete');
define('HEADING_MODULE_AUDIT','exportar arquivo auditoria');
define('TEXT_INCOME_STATEMENT','Receitas-Lançamento');

?>
