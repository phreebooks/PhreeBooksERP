<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: audit
// ISO Language: pt_br
// Version: 1
// +-----------------------------------------------------------------+
// Path: /modules/audit/language/pt_br/menu.php

define('BOX_AUDIT_MODULE','Auditoria / exportart xaf');

?>
