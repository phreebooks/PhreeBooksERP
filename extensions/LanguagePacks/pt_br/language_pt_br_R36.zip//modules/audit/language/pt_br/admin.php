<?php
// +-----------------------------------------------------------------+
// Arquivo de Tradução de Idioma Phreedom
// Generated: 2014-03-26 07:10:22
// Module/Method: audit
// ISO Language: pt_br
// Version: 1
// +-----------------------------------------------------------------+
// Path: /modules/audit/language/pt_br/admin.php

define('MODULE_AUDIT_CONFIG_INFO','Por favor defina seu arquivo de configuração');
define('TEXT_AUDIT_DEBIT_NUMBER','Seu número ou id em seu contador');
define('TEXT_AUDIT_SETTINGS','Parâmetros de auditoria');
define('BOX_AUDIT_ADMIN','Configuração auditoria.');
define('MODULE_AUDIT_TITLE','Auditoria');
define('MODULE_AUDIT_DESCRIPTION','Este módulo criará uma página na qual você pode selecionar um período para exportação como arquivo .xaf para seu contador ou autoridade fiscal.');

?>
